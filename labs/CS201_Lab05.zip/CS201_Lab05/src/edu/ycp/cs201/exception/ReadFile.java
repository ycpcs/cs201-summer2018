package edu.ycp.cs201.exception;

public class ReadFile {
	//
	// Requirements:
	// - do not add "throws IOException" (or any other throws clause)
	//   to the main() method
	// - do not test whether or not the requested file exists
	//   before trying to open it
	// - use a try/finally block to make sure that the
	//   file reader or input stream is closed
	//
	public static void main(String[] args) {
		// Prompt the user to enter a filename
		
		// Print the contents of the file to System.out
		
		// If the file can't be opened, or if an
		// IOException occurs, print an error message
	}
}
