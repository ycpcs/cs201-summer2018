package edu.ycp.cs201.change;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MakeChange {
	private static final int DENOM[] = {1, 5, 10, 21, 25};
	
	private static class Coins {
		private List<Integer> coins;
		
		public Coins() {
			coins = new ArrayList<Integer>();
		}
		
		public void add(int coin) {
			coins.add(coin);
		}
		
		public void addCoins(Coins other) {
			coins.addAll(other.coins);
		}

		public int numCoins() {
			return coins.size();
		}
		
		@Override
		public String toString() {
			return coins.toString();
		}
	}
	
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Change amount: ");
		int change = keyboard.nextInt();
		
		Coins[] memo = new Coins[change + 1];
		for (int coin : DENOM) {
			Coins oneCoin = new Coins();
			oneCoin.add(coin);
			memo[coin] = oneCoin;
		}
		
		for (int i = 1; i <= change; i++) {
			if (memo[i] == null) {
				// Construct an optimal solution for amount of money i
				Coins best = null;
				for (int coin : DENOM) {
					// See if we can construct a solution using this coin
					int remaining = i - coin;
					if (remaining > 0) {
						// Find previous solution
						Coins subprobSoln = memo[remaining];
						Coins candidate = new Coins();
						candidate.add(coin);
						candidate.addCoins(subprobSoln);
						if (best == null || candidate.numCoins() < best.numCoins()) {
							best = candidate;
						}
					}
				}
				memo[i] = best;
			}
		}
		
		System.out.println("Optimal change is: " + memo[change]);
	}
}
